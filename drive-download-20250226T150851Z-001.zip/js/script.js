function startCountdown(targetDate) {
	function updateCountdown() {
		const now = new Date().getTime();
		const distance = targetDate - now;

		if (distance <= 0) {
			(document.getElementById("days").innerText = "00"), (document.getElementById("hours").innerText = "00"), (document.getElementById("minutes").innerText = "00"), (document.getElementById("seconds").innerText = "00");
			clearInterval(timerInterval);
			return;
		}

		const days = Math.floor(distance / (1000 * 60 * 60 * 24));
		const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
		const seconds = Math.floor((distance % (1000 * 60)) / 1000);

		(document.getElementById("days").innerText = String(days).padStart(2, 0)), (document.getElementById("hours").innerText = String(hours).padStart(2, 0)), (document.getElementById("minutes").innerText = String(minutes).padStart(2, 0)), (document.getElementById("seconds").innerText = String(seconds).padStart(2, 0));
	}

	updateCountdown(); // Initial call to show the countdown immediately
	const timerInterval = setInterval(updateCountdown, 1000);
}

const targetDate = new Date("2025-04-26T09:00:00").getTime();
startCountdown(targetDate);

const formWishes = document.querySelector(".form-wishes");
const wishesList = document.querySelector(".wishes-list");
const wishesName = document.querySelector("#wishes-name");
const wishesMessage = document.querySelector("#wishes-message");
const wishesSend = document.querySelector("#wishes-send");

wishesSend.addEventListener("click", function () {
	const newWish = document.createElement("div");
	newWish.className = "wish";

	const newWishName = document.createElement("div");
	newWishName.className = "wish-name";
	newWishName.innerHTML = wishesName.value;

	const newWishMessage = document.createElement("div");
	newWishMessage.className = "wish-message";
	newWishMessage.innerHTML = wishesMessage.value;

	newWish.appendChild(newWishName);
	newWish.appendChild(newWishMessage);

	wishesList.prepend(newWish);
});
